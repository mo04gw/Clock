package clock;

public class SpinnerWindowModel {

}
